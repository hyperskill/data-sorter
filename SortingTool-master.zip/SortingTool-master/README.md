# SortingTool 
Stage #2:
Searches for strings and words with the longest length. 
Search is implemented for different command line arguments.

